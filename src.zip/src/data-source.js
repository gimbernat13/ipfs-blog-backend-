"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppDataSource = void 0;
require("reflect-metadata");
const typeorm_1 = require("typeorm");
const Post = require("./entity/Post");
const Category = require("./entity/Category");
const User = require("./entity/User");
const File = require("./entity/File");



exports.AppDataSource = new typeorm_1.DataSource({
    type: "postgres",
    host: "localhost",
    port: 5432,
    username: "postgres",
    password: "1234",
    database: "gigz",
    synchronize: true,
    logging: true,
    entities: [
        __dirname + "/entity/*.ts"
    ], subscribers: [],
    migrations: [],
});
//# sourceMappingURL=data-source.js.map


