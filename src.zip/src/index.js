"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const Post_1 = require("./entity/Post");
const data_source_1 = require("./data-source");
const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");
dotenv.config();
const SECRET_JWT_KEY = process.env.SECRET_JWT_KEY || "myFallbackSecretKey";
data_source_1.AppDataSource.initialize()
    .then(() => {
    console.log("✅ Initialized data source");
})
    .catch((error) => {
    console.log("❌ Could not initialize data source:", error);
    process.exit(1); // Exit process with failure
});
const app = express();
app.use(express.json());
const users = [
    {
        id: 1,
        username: "admin",
        password: bcrypt.hashSync(process.env.ADMIN_PASSWORD || "", 8),
    },
];
app.post("/login", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { username, password } = req.body;
        const adminUsername = process.env.ADMIN_USERNAME;
        const adminPassword = bcrypt.hashSync(process.env.ADMIN_PASSWORD || "", 8);
        if (username !== adminUsername || !bcrypt.compareSync(password, adminPassword)) {
            console.log("request ", username, password);
            return res.status(401).send("Invalid username or password.");
        }
        const token = jwt.sign({ id: adminUsername }, SECRET_JWT_KEY, {
            expiresIn: 86400,
        });
        res.status(200).send({ auth: true, token });
    }
    catch (error) {
        console.log("Error in /login:", error);
        res.status(500).send("Internal Server Error");
    }
}));
app.get("/posts", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const posts = yield data_source_1.AppDataSource.getRepository(Post_1.Post).find();
        res.json(posts);
    }
    catch (error) {
        console.log("Error in /posts:", error);
        res.status(500).send("Internal Server Error");
    }
}));
app.listen(8000, () => {
    console.log("Server running on port 8000");
});
//# sourceMappingURL=index.js.map